const { Builder, By, until } = require('selenium-webdriver');
const assert = require('assert');
const fs = require('fs');

describe('US-3: Historial de Reciclaje Test', function () {
  let driver;

  this.timeout(15000);

  before(async () => {
    driver = await new Builder().forBrowser('chrome').build();
  });

  it('should login and view the recycling history', async () => {
    // Paso 1: Login
    await driver.get('https://witmaxer.net/login.php');
    await driver.findElement(By.id('email')).sendKeys('OLIVERadames20@gmail.com');
    await driver.findElement(By.id('password')).sendKeys('12345678');
    await driver.findElement(By.css('button[type="submit"]')).click();

    // Esperar que cargue el dashboard
    await driver.wait(until.urlContains('dashboard.php'), 5000);

    // Paso 2: Ir al Historial de Reciclaje
    await driver.findElement(By.linkText('Historial de reciclaje')).click();
    await driver.wait(until.urlContains('recycling/history.php'), 5000);

    // Paso 3: Verificar que la página cargó correctamente
    const title = await driver.findElement(By.css('.main-content h2')).getText();
    assert.strictEqual(title.trim(), 'Historial de Reciclaje');

    // Paso 4: Verificar que se muestren estadísticas
    const stats = await driver.findElements(By.css('.recycling-stats .stat-card .stat-value'));
    assert.strictEqual(stats.length, 3, 'No se encontraron las 3 estadísticas principales');

    for (let stat of stats) {
      const value = await stat.getText();
      assert.ok(value !== '', 'Una estadística está vacía');
    }

    // Paso 5: Verificar que existe la tabla de historial (o mensaje si no hay registros)
    const tableRows = await driver.findElements(By.css('.history-table tbody tr'));

    if (tableRows.length > 0) {
      console.log(`📋 Se encontraron ${tableRows.length} registros en el historial`);
      // Verificamos que cada fila tenga al menos 6 columnas (Fecha, Material, Peso, etc.)
      for (let row of tableRows) {
        const cols = await row.findElements(By.css('td'));
        assert.strictEqual(cols.length, 6, 'Una fila no tiene las 6 columnas esperadas');
      }
    } else {
      // Verificamos que se muestre el mensaje de que no hay registros
      const alertMsg = await driver.findElement(By.css('.alert.alert-info')).getText();
      assert.ok(alertMsg.includes('No hay registros'), 'No se mostró el mensaje de alerta esperado');
    }
  });

  after(async () => {
    if (driver) {
      try {
        const screenshot = await driver.takeScreenshot();
        if (!fs.existsSync('screenshots')) {
          fs.mkdirSync('screenshots');
        }
        fs.writeFileSync('screenshots/history_test.png', screenshot, 'base64');
        console.log("✅ Captura de historial guardada en /screenshots/history_test.png");
      } catch (err) {
        console.error("❌ Error al capturar pantalla:", err);
      } finally {
        await driver.quit();
      }
    }
  });
});
