const { Builder, By, until } = require('selenium-webdriver');
const assert = require('assert');
const fs = require('fs');

describe('US-2: Registro de nuevo usuario', function () {
  let driver;

  this.timeout(20000); // Tiempo aumentado por si tarda en cargar

  before(async () => {
    driver = await new Builder().forBrowser('chrome').build();
  });

  it('should register a new user successfully', async () => {
    await driver.get('https://witmaxer.net/register.php');

    // Llenar los campos con datos únicos para evitar duplicados
    const randomSuffix = Math.floor(Math.random() * 10000);
    const testEmail = `usuario${randomSuffix}@test.com`;

    await driver.findElement(By.id('name')).sendKeys('luismanuel@gmail.com');
    await driver.findElement(By.id('email')).sendKeys(testEmail);
    await driver.findElement(By.id('phone')).sendKeys('8095551234');
    await driver.findElement(By.id('password')).sendKeys('ClaveFuerte1!');
    await driver.findElement(By.id('confirm_password')).sendKeys('ClaveFuerte1!');
    await driver.findElement(By.id('terms')).click();

    await driver.findElement(By.css('button[type="submit"]')).click();

    // Esperar alguna señal de éxito: redirección o mensaje
    await driver.wait(until.urlContains('login.php'), 5000);
    const currentUrl = await driver.getCurrentUrl();

    // Confirmar que fue redirigido a login.php después de registrarse
    assert.ok(currentUrl.includes('login.php'), 'No se redirigió al login después del registro.');
  });

  after(async () => {
    if (driver) {
      try {
        const screenshot = await driver.takeScreenshot();
        if (!fs.existsSync('screenshots')) {
          fs.mkdirSync('screenshots');
        }
        fs.writeFileSync('screenshots/register_test.png', screenshot, 'base64');
        console.log("✅ Captura del registro guardada en /screenshots/register_test.png");
      } catch (err) {
        console.error("❌ Error al capturar pantalla:", err);
      } finally {
        await driver.quit();
      }
    }
  });
});
