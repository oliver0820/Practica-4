const { Builder, By, until } = require('selenium-webdriver');
const assert = require('assert');
const fs = require('fs');

describe('US-1: Login Test', function () {
  let driver;

  this.timeout(15000); // más tiempo por si el navegador tarda en cargar

  before(async () => {
    driver = await new Builder().forBrowser('chrome').build();
  });

  it('should login successfully with valid credentials', async () => {
    await driver.get('https://witmaxer.net/login.php');

    // Rellenar el formulario con los ID correctos
    await driver.findElement(By.id('email')).sendKeys('OLIVERadames20@gmail.com');
    await driver.findElement(By.id('password')).sendKeys('12345678');

    // Verificar que el botón de submit esté visible antes de hacer clic
    const submitButton = await driver.findElement(By.css('button[type="submit"]'));
    await driver.wait(until.elementIsVisible(submitButton), 5000); // Espera explícita para asegurar que el botón sea visible
    await submitButton.click();

    // Esperar que se redirija o aparezca algo que confirme el login
    await driver.wait(until.urlContains('dashboard.php'), 5000);

    // Verificar que la URL contenga "dashboard.php"
    const currentUrl = await driver.getCurrentUrl();
    assert.ok(currentUrl.includes('dashboard.php'));

    // Verificar que algún elemento específico de la página de dashboard esté presente
    const dashboardElement = await driver.findElement(By.id('dashboardWelcome')); // Ajusta según el id de algún elemento en el dashboard
    await driver.wait(until.elementIsVisible(dashboardElement), 5000); // Asegurarse que el elemento es visible
    const dashboardText = await dashboardElement.getText();
    assert.ok(dashboardText.includes('Bienvenido'), 'El texto del dashboard no es el esperado');
  });

  after(async () => {
    if (driver) {
      try {
        const screenshot = await driver.takeScreenshot();
        if (!fs.existsSync('screenshots')) {
          fs.mkdirSync('screenshots');
        }
        fs.writeFileSync('screenshots/login_test.png', screenshot, 'base64');
        console.log("✅ Captura de login guardada en /screenshots/login_test.png");
      } catch (err) {
        console.error("❌ Error al capturar pantalla:", err);
      } finally {
        await driver.quit();
      }
    }
  });
});
