const { Builder, By, until } = require('selenium-webdriver');
const assert = require('assert');
const fs = require('fs');

describe('US-4: Logout Test', function () {
  let driver;

  this.timeout(15000);

  before(async () => {
    driver = await new Builder().forBrowser('chrome').build();
  });

  it('should login and logout successfully', async () => {
    // Paso 1: Login
    await driver.get('https://witmaxer.net/login.php');
    await driver.findElement(By.id('email')).sendKeys('OLIVERadames20@gmail.com');
    await driver.findElement(By.id('password')).sendKeys('12345678');
    await driver.findElement(By.css('button[type="submit"]')).click();

    // Esperar que cargue el dashboard
    await driver.wait(until.urlContains('dashboard.php'), 5000);

    // Paso 2: Cerrar sesión
    await driver.findElement(By.linkText('Cerrar sesión')).click();

    // Paso 3: Verificar que se redirige al login
    await driver.wait(until.urlContains('login.php'), 5000);
    const currentUrl = await driver.getCurrentUrl();
    assert.ok(currentUrl.includes('login.php'), 'No se redirigió al login tras cerrar sesión');
  });

  after(async () => {
    if (driver) {
      try {
        const screenshot = await driver.takeScreenshot();
        if (!fs.existsSync('screenshots')) {
          fs.mkdirSync('screenshots');
        }
        fs.writeFileSync('screenshots/logout_test.png', screenshot, 'base64');
        console.log("✅ Captura de cierre de sesión guardada en /screenshots/logout_test.png");
      } catch (err) {
        console.error("❌ Error al capturar pantalla:", err);
      } finally {
        await driver.quit();
      }
    }
  });
});
