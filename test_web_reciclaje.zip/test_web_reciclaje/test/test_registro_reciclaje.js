const { Builder, By, until } = require('selenium-webdriver');
const assert = require('assert');
const fs = require('fs');

describe('US-2: Registro de Reciclaje Test', function () {
  let driver;

  this.timeout(15000); // Aumentamos el tiempo de espera si es necesario

  before(async () => {
    driver = await new Builder().forBrowser('chrome').build();
  });

  it('should login and navigate to dashboard and access recycling form', async () => {
    await driver.get('https://witmaxer.net/login.php');
    await driver.findElement(By.id('email')).sendKeys('OLIVERadames20@gmail.com');
    await driver.findElement(By.id('password')).sendKeys('12345678');
    const submitButton = await driver.findElement(By.css('button[type="submit"]'));
    await submitButton.click();

    await driver.wait(until.urlContains('dashboard.php'), 5000);
    const currentUrl = await driver.getCurrentUrl();
    assert.ok(currentUrl.includes('dashboard.php'));

    const userProfile = await driver.findElement(By.css('.user-profile'));
    const userName = await userProfile.findElement(By.tagName('h4')).getText();
    assert.strictEqual(userName, 'Oliver Adames', 'El nombre de usuario no coincide');

    const points = await driver.findElement(By.css('.user-points .points')).getText();
    assert.ok(Number(points) > 0, 'El total de puntos debería ser mayor que cero');

    const sidebarLinks = await driver.findElements(By.css('.dashboard-nav ul li a'));
    const menuItems = ['Inicio', 'Canje de recompensas', 'Recompensas disponibles', 'Historial de reciclaje', 'Registro de reciclaje', 'Perfil de usuario', 'Cerrar sesión'];

    for (let i = 0; i < menuItems.length; i++) {
      const linkText = await sidebarLinks[i].getText();
      assert.strictEqual(linkText.trim(), menuItems[i], `El elemento de menú "${menuItems[i]}" no está presente o es incorrecto`);
    }

    await driver.findElement(By.linkText('Registro de reciclaje')).click();

    await driver.wait(until.urlContains('recycling/register.php'), 5000);
    const currentUrlAfterClick = await driver.getCurrentUrl();
    assert.ok(currentUrlAfterClick.includes('recycling/register.php'));

    const form = await driver.findElement(By.css('.recycling-form'));
    assert.ok(form);

    const materialSelect = await driver.findElement(By.id('material_id'));
    await materialSelect.click();
    await driver.findElement(By.xpath("//option[@value='1']")).click();  // Cartón

    const weightInput = await driver.findElement(By.id('weight'));
    await weightInput.sendKeys('20');

    await driver.sleep(1000);

    const pointsInput = await driver.findElement(By.id('points'));
    const pointsValue = await pointsInput.getAttribute('value');
    assert.strictEqual(pointsValue, '70.00', 'Los puntos calculados no son correctos');

    const recyclingCenterInput = await driver.findElement(By.id('recycling_center'));
    await recyclingCenterInput.sendKeys('Centro de Reciclaje Los Corales');

    const submitFormButton = await driver.findElement(By.css('.btn.btn-primary'));
    await submitFormButton.click();

    await driver.wait(until.urlContains('register.php'), 5000);
    const currentUrlAfterSubmit = await driver.getCurrentUrl();
    assert.ok(currentUrlAfterSubmit.includes('register.php'));

    // ✅ Captura después de registrar reciclaje
    const screenshot = await driver.takeScreenshot();
    if (!fs.existsSync('screenshots')) {
      fs.mkdirSync('screenshots');
    }
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    fs.writeFileSync(`screenshots/recycling_test_${timestamp}.png`, screenshot, 'base64');
    console.log("✅ Captura tomada al final del test");
  });

  after(async () => {
    if (driver) {
      await driver.quit();
    }
  });
});
