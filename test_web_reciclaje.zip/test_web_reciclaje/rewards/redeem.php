<?php
include '../includes/config.php';
include '../includes/header.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Process reward redemption
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['redeem'])) {
    $reward_id = $_POST['reward_id'];
    
    // Get reward details
    $stmt = $db->prepare("SELECT * FROM rewards WHERE id = ?");
    $stmt->execute([$reward_id]);
    $reward = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get user points
    $stmt = $db->prepare("SELECT SUM(points) as total_points FROM recycling_history WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $points = $stmt->fetch(PDO::FETCH_ASSOC);
    $total_points = $points['total_points'] ?? 0;
    
    // Check if user has enough points
    if($total_points >= $reward['points_required']) {
        // Insert redemption record
        $stmt = $db->prepare("INSERT INTO reward_redemptions (user_id, reward_id, redemption_date) VALUES (?, ?, NOW())");
        $stmt->execute([$_SESSION['user_id'], $reward_id]);
        
        // Deduct points (optional, depending on your business logic)
        // $stmt = $db->prepare("INSERT INTO point_transactions (user_id, points, transaction_type, description) VALUES (?, -?, 'redemption', 'Canje de recompensa')");
        // $stmt->execute([$_SESSION['user_id'], $reward['points_required']]);
        
        $_SESSION['success_message'] = "¡Recompensa canjeada con éxito!";
    } else {
        $_SESSION['error_message'] = "No tienes suficientes puntos para canjear esta recompensa.";
    }
    
    header("Location: redeem.php");
    exit;
}

// Get available rewards
$stmt = $db->prepare("SELECT * FROM rewards WHERE active = 1");
$stmt->execute();
$rewards = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user points
$stmt = $db->prepare("SELECT SUM(points) as total_points FROM recycling_history WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$points = $stmt->fetch(PDO::FETCH_ASSOC);
$total_points = $points['total_points'] ?? 0;
?>

<div class="dashboard-container">
    <?php include '../includes/dashboard-sidebar.php'; ?>
    
    <div class="main-content">
        <h2>Canje de Recompensas</h2>
        
        <?php if(isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
        <?php endif; ?>
        
        <?php if(isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
        <?php endif; ?>
        
        <div class="points-balance">
            <h3>Saldo de Puntos: <span><?php echo $total_points; ?></span></h3>
        </div>
        
        <div class="rewards-grid">
            <?php foreach($rewards as $reward): ?>
                <div class="reward-card">
                    <div class="reward-image">
                        <img src="../assets/images/rewards/<?php echo $reward['image']; ?>" alt="<?php echo htmlspecialchars($reward['name']); ?>">
                    </div>
                    <div class="reward-details">
                        <h3><?php echo htmlspecialchars($reward['name']); ?></h3>
                        <p><?php echo htmlspecialchars($reward['description']); ?></p>
                        <div class="reward-points"><?php echo $reward['points_required']; ?> puntos</div>
                        
                        <form method="POST" action="redeem.php">
                            <input type="hidden" name="reward_id" value="<?php echo $reward['id']; ?>">
                            <button type="submit" name="redeem" class="btn btn-primary" <?php echo ($total_points < $reward['points_required']) ? 'disabled' : ''; ?>>
                                Canjear
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>