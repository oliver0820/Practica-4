<?php
function getTotalRecycledWeight($user_id) {
    global $db;
    
    $stmt = $db->prepare("SELECT SUM(weight) as total_weight FROM recycling_history WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $result['total_weight'] ?? 0;
}

function getTotalRewardsClaimed($user_id) {
    global $db;
    
    $stmt = $db->prepare("SELECT COUNT(*) as total_rewards FROM reward_redemptions WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $result['total_rewards'] ?? 0;
}

function getMaterialPoints($material_id) {
    global $db;
    
    $stmt = $db->prepare("SELECT points_per_kg FROM materials WHERE id = ?");
    $stmt->execute([$material_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $result['points_per_kg'] ?? 0;
}

function calculatePoints($weight, $material_id) {
    $points_per_kg = getMaterialPoints($material_id);
    return $weight * $points_per_kg;
}
?>