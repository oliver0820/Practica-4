<?php
// includes/dashboard-sidebar.php

// Verificar si el usuario está logueado
if(!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Obtener datos del usuario
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Obtener puntos del usuario
$stmt = $db->prepare("SELECT SUM(points) as total_points FROM recycling_history WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$points = $stmt->fetch(PDO::FETCH_ASSOC);
$total_points = $points['total_points'] ?? 0;
?>

<div class="sidebar">
    <div class="user-profile">
    
        <h4><?php echo htmlspecialchars($user['name']); ?></h4>
        <div class="user-points">
            <span class="points"><?php echo $total_points; ?></span> puntos
        </div>
    </div>
    
    <nav class="dashboard-nav">
        <ul>
            <li><a href="../dashboard.php" <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-home"></i> Inicio
            </a></li>
            <li><a href="../rewards/redeem.php" <?php echo basename($_SERVER['PHP_SELF']) == 'redeem.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-gift"></i> Canje de recompensas
            </a></li>
            <li><a href="../rewards/available.php" <?php echo basename($_SERVER['PHP_SELF']) == 'available.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-star"></i> Recompensas disponibles
            </a></li>
            <li><a href="../recycling/history.php" <?php echo basename($_SERVER['PHP_SELF']) == 'history.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-history"></i> Historial de reciclaje
            </a></li>
            <li><a href="../recycling/register.php" <?php echo basename($_SERVER['PHP_SELF']) == 'register.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-plus-circle"></i> Registro de reciclaje
            </a></li>
            <li><a href="../user/profile.php" <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'class="active"' : ''; ?>>
                <i class="fas fa-user"></i> Perfil de usuario
            </a></li>
            <li><a href="../logout.php">
                <i class="fas fa-sign-out-alt"></i> Cerrar sesión
            </a></li>
        </ul>
    </nav>
</div>