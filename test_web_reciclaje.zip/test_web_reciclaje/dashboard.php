<?php
include 'includes/config.php';
include 'includes/header.php';
include 'includes/functions.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get user data
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Get user points
$stmt = $db->prepare("SELECT SUM(points) as total_points FROM recycling_history WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$points = $stmt->fetch(PDO::FETCH_ASSOC);
$total_points = $points['total_points'] ?? 0;
?>
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/custom.css">
<div class="dashboard-container">
    <div class="sidebar">
        <div class="user-profile">
           
            <h4><?php echo htmlspecialchars($user['name']); ?></h4>
            <div class="user-points">
                <span class="points"><?php echo $total_points; ?></span> puntos
            </div>
        </div>
        
        <nav class="dashboard-nav">
            <ul>
                <li class="active"><a href="dashboard.php"><i class="fas fa-home"></i> Inicio</a></li>
                <li><a href="rewards/redeem.php"><i class="fas fa-gift"></i> Canje de recompensas</a></li>
                <li><a href="rewards/available.php"><i class="fas fa-star"></i> Recompensas disponibles</a></li>
                <li><a href="recycling/history.php"><i class="fas fa-history"></i> Historial de reciclaje</a></li>
                <li><a href="recycling/register.php"><i class="fas fa-plus-circle"></i> Registro de reciclaje</a></li>
                <li><a href="user/profile.php"><i class="fas fa-user"></i> Perfil de usuario</a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Cerrar sesión</a></li>
            </ul>
        </nav>
    </div>
    
    <div class="main-content">
        <h2>Bienvenido al Programa de Reciclaje</h2>
        
        <div class="stats-cards">
            <div class="stat-card">
                <h3>Puntos Acumulados</h3>
                <div class="stat-value"><?php echo $total_points; ?></div>
                <p>Puntos disponibles para canjear</p>
            </div>
            
            <div class="stat-card">
                <h3>Material Reciclado</h3>
                <div class="stat-value"><?php echo getTotalRecycledWeight($_SESSION['user_id']); ?> kg</div>
                <p>Total de material reciclado</p>
            </div>
            
            <div class="stat-card">
                <h3>Recompensas</h3>
                <div class="stat-value"><?php echo getTotalRewardsClaimed($_SESSION['user_id']); ?></div>
                <p>Recompensas canjeadas</p>
            </div>
        </div>
        
        <div class="quick-actions">
            <h3>Acciones Rápidas</h3>
            <div class="actions">
                <a href="recycling/register.php" class="action-btn">
                    <i class="fas fa-plus-circle"></i>
                    <span>Registrar Reciclaje</span>
                </a>
                <a href="rewards/available.php" class="action-btn">
                    <i class="fas fa-gift"></i>
                    <span>Ver Recompensas</span>
                </a>
                <a href="recycling/history.php" class="action-btn">
                    <i class="fas fa-history"></i>
                    <span>Ver Historial</span>
                </a>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>