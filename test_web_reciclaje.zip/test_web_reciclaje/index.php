<?php include 'includes/header.php'; ?>

<div class="hero-section">
    <div class="container">
        <h1>Programa de Reciclaje con Incentivos</h1>
        <p>Recicla y gana recompensas por ayudar al medio ambiente</p>
        
        <?php if(!isset($_SESSION['user_id'])): ?>
            <div class="auth-buttons">
                <a href="login.php" class="btn btn-primary">Iniciar Sesión</a>
                <a href="register.php" class="btn btn-secondary">Registrarse</a>
            </div>
        <?php else: ?>
            <a href="dashboard.php" class="btn btn-success">Ir al Panel</a>
        <?php endif; ?>
    </div>
</div>

<div class="features-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="feature-card">
                    <i class="fas fa-recycle"></i>
                    <h3>Registra tu Reciclaje</h3>
                    <p>Registra los materiales que reciclas y acumula puntos.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card">
                    <i class="fas fa-gift"></i>
                    <h3>Canjea Recompensas</h3>
                    <p>Usa tus puntos para obtener descuentos y beneficios.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card">
                    <i class="fas fa-chart-line"></i>
                    <h3>Sigue tu Progreso</h3>
                    <p>Mira tu historial y el impacto ambiental que has generado.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>