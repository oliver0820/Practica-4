<?php
include 'includes/config.php';

// Redirect if already logged in
if(isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}

// Process registration form
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $phone = trim($_POST['phone']);
    
    // Validate inputs
    $errors = [];
    
    if(empty($name)) {
        $errors[] = "El nombre es requerido.";
    }
    
    if(empty($email)) {
        $errors[] = "El email es requerido.";
    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "El email no tiene un formato válido.";
    } else {
        // Check if email already exists
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if($stmt->fetch()) {
            $errors[] = "Este email ya está registrado.";
        }
    }
    
    if(empty($password)) {
        $errors[] = "La contraseña es requerida.";
    } elseif(strlen($password) < 8) {
        $errors[] = "La contraseña debe tener al menos 8 caracteres.";
    } elseif($password !== $confirm_password) {
        $errors[] = "Las contraseñas no coinciden.";
    }
    
    // If no errors, register user
    if(empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $db->prepare("INSERT INTO users (name, email, password, phone, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$name, $email, $hashed_password, $phone]);
        
        // Get the new user ID
        $user_id = $db->lastInsertId();
        
        // Log in the user
        $_SESSION['user_id'] = $user_id;
        $_SESSION['user_name'] = $name;
        $_SESSION['user_email'] = $email;
        
        // Redirect to dashboard
        $_SESSION['success_message'] = "¡Registro exitoso! Bienvenido/a al programa de reciclaje.";
        header("Location: dashboard.php");
        exit;
    } else {
        $_SESSION['error_messages'] = $errors;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Programa de Reciclaje</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/custom.css">
</head>
<body class="register-page">
    <div class="register-container">
        <div class="register-card">
            <div class="register-header">
                <img src="assets/images/logo.png" alt="Logo Reciclaje" class="register-logo">
                <h2>Crear una cuenta</h2>
                <p>Únete a nuestro programa de reciclaje y comienza a ganar recompensas</p>
            </div>
            
            <?php if(isset($_SESSION['error_messages'])): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php foreach($_SESSION['error_messages'] as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php unset($_SESSION['error_messages']); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="register.php" class="register-form">
                <div class="form-group">
                    <label for="name">Nombre completo:</label>
                    <input type="text" name="name" id="name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Teléfono (opcional):</label>
                    <input type="tel" name="phone" id="phone" class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="password">Contraseña:</label>
                    <input type="password" name="password" id="password" class="form-control" required>
                    <small class="form-text text-muted">Mínimo 8 caracteres</small>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirmar contraseña:</label>
                    <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
                </div>
                
                <div class="form-group form-check">
                    <input type="checkbox" name="terms" id="terms" class="form-check-input" required>
                    <label for="terms" class="form-check-label">Acepto los <a href="terms.php">términos y condiciones</a></label>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Registrarse</button>
                
                <div class="register-links">
                    ¿Ya tienes una cuenta? <a href="login.php">Inicia sesión aquí</a>
                </div>
            </form>
        </div>
    </div>

    <script src="assets/js/jquery-3.5.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script>
    // Password strength indicator
    $('#password').on('input', function() {
        const password = $(this).val();
        let strength = 0;
        
        if(password.length >= 8) strength++;
        if(password.match(/[A-Z]/)) strength++;
        if(password.match(/[0-9]/)) strength++;
        if(password.match(/[^A-Za-z0-9]/)) strength++;
        
        // Update UI based on strength
        // You can implement a visual indicator here
    });
    </script>
</body>
</html>