<?php
include '../includes/config.php';
include '../includes/header.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Get available rewards
$stmt = $db->prepare("SELECT * FROM rewards WHERE active = 1");
$stmt->execute();
$rewards = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user points
$stmt = $db->prepare("SELECT SUM(points) as total_points FROM recycling_history WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$points = $stmt->fetch(PDO::FETCH_ASSOC);
$total_points = $points['total_points'] ?? 0;
?>

<div class="dashboard-container">
    <?php include '../includes/dashboard-sidebar.php'; ?>
    
    <div class="main-content">
        <h2>Recompensas Disponibles</h2>
        
        <div class="points-balance">
            <h3>Saldo de Puntos: <span><?php echo $total_points; ?></span></h3>
        </div>
        
        <div class="rewards-filter">
            <form method="GET">
                <div class="form-group">
                    <label for="category">Filtrar por categoría:</label>
                    <select name="category" id="category" class="form-control">
                        <option value="all">Todas las categorías</option>
                        <option value="discount">Descuentos</option>
                        <option value="product">Productos</option>
                        <option value="experience">Experiencias</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Filtrar</button>
            </form>
        </div>
        
        <div class="rewards-list">
            <?php foreach($rewards as $reward): ?>
                <div class="reward-item">
                    <div class="reward-image">
                        <img src="../assets/images/rewards/<?php echo $reward['image']; ?>" alt="<?php echo htmlspecialchars($reward['name']); ?>">
                    </div>
                    <div class="reward-info">
                        <h3><?php echo htmlspecialchars($reward['name']); ?></h3>
                        <p class="reward-description"><?php echo htmlspecialchars($reward['description']); ?></p>
                        <p class="reward-category">Categoría: <?php echo htmlspecialchars($reward['category']); ?></p>
                    </div>
                    <div class="reward-action">
                        <div class="points-required"><?php echo $reward['points_required']; ?> puntos</div>
                        <a href="redeem.php?reward_id=<?php echo $reward['id']; ?>" class="btn btn-primary">Canjear</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>