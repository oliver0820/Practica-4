<?php
include '../includes/config.php';
include '../includes/header.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Get user data
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Process form submission
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    
    // Update user data
    $stmt = $db->prepare("UPDATE users SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?");
    $stmt->execute([$name, $email, $phone, $address, $_SESSION['user_id']]);
    
    $_SESSION['success_message'] = "Perfil actualizado con éxito!";
    header("Location: profile.php");
    exit;
}

// Get user points
$stmt = $db->prepare("SELECT SUM(points) as total_points FROM recycling_history WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$points = $stmt->fetch(PDO::FETCH_ASSOC);
$total_points = $points['total_points'] ?? 0;

// Get recycling stats
$stmt = $db->prepare("SELECT COUNT(*) as total_recyclings, SUM(weight) as total_weight FROM recycling_history WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<div class="dashboard-container">
    <?php include '../includes/dashboard-sidebar.php'; ?>
    
    <div class="main-content">
        <h2>Perfil de Usuario</h2>
        
        <?php if(isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
        <?php endif; ?>
        
        <div class="profile-section">
            <div class="profile-stats">
                <div class="stat-card">
                    <h3>Puntos Acumulados</h3>
                    <div class="stat-value"><?php echo $total_points; ?></div>
                </div>
                <div class="stat-card">
                    <h3>Reciclajes</h3>
                    <div class="stat-value"><?php echo $stats['total_recyclings']; ?></div>
                </div>
                <div class="stat-card">
                    <h3>Material Reciclado</h3>
                    <div class="stat-value"><?php echo $stats['total_weight'] ?? 0; ?> kg</div>
                </div>
            </div>
            
            <div class="profile-form">
                <form method="POST" action="profile.php">
                    <div class="form-group">
                        <label for="name">Nombre:</label>
                        <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Teléfono:</label>
                        <input type="tel" name="phone" id="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="address">Dirección:</label>
                        <textarea name="address" id="address" class="form-control"><?php echo htmlspecialchars($user['address']); ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Actualizar Perfil</button>
                </form>
                
                <div class="change-password">
                    <h3>Cambiar Contraseña</h3>
                    <a href="change-password.php" class="btn btn-secondary">Cambiar Contraseña</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>