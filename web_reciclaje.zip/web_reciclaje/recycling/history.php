<?php
include '../includes/config.php';
include '../includes/header.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Get recycling history
$stmt = $db->prepare("SELECT rh.*, m.name as material_name, m.points_per_kg 
                      FROM recycling_history rh
                      JOIN materials m ON rh.material_id = m.id
                      WHERE rh.user_id = ?
                      ORDER BY rh.recycling_date DESC");
$stmt->execute([$_SESSION['user_id']]);
$history = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$total_weight = 0;
$total_points = 0;
foreach($history as $record) {
    $total_weight += $record['weight'];
    $total_points += $record['points'];
}
?>

<div class="dashboard-container">
    <?php include '../includes/dashboard-sidebar.php'; ?>
    
    <div class="main-content">
        <h2>Historial de Reciclaje</h2>
        
        <div class="recycling-stats">
            <div class="stat-card">
                <h3>Total Reciclado</h3>
                <div class="stat-value"><?php echo $total_weight; ?> kg</div>
            </div>
            <div class="stat-card">
                <h3>Puntos Obtenidos</h3>
                <div class="stat-value"><?php echo $total_points; ?></div>
            </div>
            <div class="stat-card">
                <h3>Registros</h3>
                <div class="stat-value"><?php echo count($history); ?></div>
            </div>
        </div>
        
        <div class="history-table">
            <table class="table">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Material</th>
                        <th>Peso (kg)</th>
                        <th>Puntos/kg</th>
                        <th>Puntos</th>
                        <th>Centro</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($history as $record): ?>
                        <tr>
                            <td><?php echo date('d/m/Y', strtotime($record['recycling_date'])); ?></td>
                            <td><?php echo htmlspecialchars($record['material_name']); ?></td>
                            <td><?php echo $record['weight']; ?></td>
                            <td><?php echo $record['points_per_kg']; ?></td>
                            <td><?php echo $record['points']; ?></td>
                            <td><?php echo htmlspecialchars($record['recycling_center']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <?php if(empty($history)): ?>
            <div class="alert alert-info">No hay registros de reciclaje aún.</div>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>