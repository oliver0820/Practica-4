<?php
include '../includes/config.php';
include '../includes/header.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Get materials for dropdown
$stmt = $db->prepare("SELECT * FROM materials WHERE active = 1");
$stmt->execute();
$materials = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Process form submission
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $material_id = $_POST['material_id'];
    $weight = $_POST['weight'];
    $recycling_center = $_POST['recycling_center'];
    $recycling_date = $_POST['recycling_date'];
    
    // Get material points per kg
    $stmt = $db->prepare("SELECT points_per_kg FROM materials WHERE id = ?");
    $stmt->execute([$material_id]);
    $material = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $points = $weight * $material['points_per_kg'];
    
    // Insert record
    $stmt = $db->prepare("INSERT INTO recycling_history 
                         (user_id, material_id, weight, points, recycling_center, recycling_date) 
                         VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $material_id, $weight, $points, $recycling_center, $recycling_date]);
    
    $_SESSION['success_message'] = "Reciclaje registrado con éxito! Has ganado $points puntos.";
    header("Location: history.php");
    exit;
}
?>

<div class="dashboard-container">
    
    <div class="main-content">
        <h2>Registro de Reciclaje</h2>
        
        <form method="POST" action="register.php" class="recycling-form">
            <div class="form-group">
                <label for="material_id">Material Reciclado:</label>
                <select name="material_id" id="material_id" class="form-control" required>
                    <option value="">Selecciona un material</option>
                    <?php foreach($materials as $material): ?>
                        <option value="<?php echo $material['id']; ?>" data-points="<?php echo $material['points_per_kg']; ?>">
                            <?php echo htmlspecialchars($material['name']); ?> (<?php echo $material['points_per_kg']; ?> pts/kg)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="weight">Peso (kg):</label>
                <input type="number" name="weight" id="weight" class="form-control" step="0.1" min="0.1" required>
            </div>
            
            <div class="form-group">
                <label for="points">Puntos estimados:</label>
                <input type="text" name="points" id="points" class="form-control" readonly>
            </div>
            
            <div class="form-group">
                <label for="recycling_center">Centro de Reciclaje:</label>
                <input type="text" name="recycling_center" id="recycling_center" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="recycling_date">Fecha de Reciclaje:</label>
                <input type="date" name="recycling_date" id="recycling_date" class="form-control" required value="<?php echo date('Y-m-d'); ?>">
            </div>
            
            <button type="submit" class="btn btn-primary">Registrar Reciclaje</button>
        </form>
    </div>
</div>

<script>
// Calculate estimated points
document.getElementById('material_id').addEventListener('change', calculatePoints);
document.getElementById('weight').addEventListener('input', calculatePoints);

function calculatePoints() {
    const materialSelect = document.getElementById('material_id');
    const weightInput = document.getElementById('weight');
    const pointsInput = document.getElementById('points');
    
    if(materialSelect.value && weightInput.value) {
        const pointsPerKg = materialSelect.options[materialSelect.selectedIndex].getAttribute('data-points');
        const points = (parseFloat(weightInput.value) * parseFloat(pointsPerKg)).toFixed(2);
        pointsInput.value = points;
    } else {
        pointsInput.value = '';
    }
}
</script>

<?php include '../includes/footer.php'; ?>